/******************************************************************************

Write a program in C++ to use map associative container. The keys will be the names of states and the values
will be the population of the state. When the program runs, the user is prompted to type the name of a state.
The program then looks in the map, using the state name as an index and returns the population of the state.

Tasks Involved
1. Creating an empty map associative container.
2. Insert key as name of state.
3. Insert value as population of the state.
4. Accept input (name of state) from user and display population of that state
*******************************************************************************/

#include <iostream>
#include <map>
#include <string>
using namespace std;

int main()
{
	typedef map<string,int>mapType;
	mapType populationMap;
	
	populationMap.insert(pair<string,int>("Maharashtra",254589655));
	populationMap.insert(pair<string,int>("Gujrat",58674589));
	populationMap.insert(pair<string,int>("Bihar",89695896));
	populationMap.insert(pair<string,int>("Goa",4589655));
	populationMap.insert(pair<string,int>("Sikkim",96855));
	
	mapType :: iterator iter;
	
	cout<<"**********Population of states in India***********\n";
	
	cout<<"\n Size of population : "<<populationMap.size()<<"\n";
	
	string state_name;
	cout<<"\n Enter the state name : ";
	cin>>state_name;
	
	iter = populationMap.find(state_name);
	if(iter != populationMap.end()){
		cout<<state_name<<" population is : "<<iter->second;
	}
	else{
		cout<<"Key is not in poplationMap\n";
	}
	return 0;
}




