/******************************************************************************

Write a C++ program that creates an output file, writes information to it, closes the file, open
it again as an input file and read the information from the file.
*******************************************************************************/

#include<iostream>
#include<fstream>
using namespace std;
class Student
{
	private:
		string name;
		int rollno;
	public:
		void add_info()
		{
			ofstream fs;
			fs.open("sample.txt",ios::app);
			if(!fs)
				cout<<"\nFile creation failed..."<<endl;
			else
			{
				cout<<"\nEnter name of student: ";
				cin>>name;
				cout<<"\nEnter rollno of student: ";
				cin>>rollno;
				fs<<name<<": "<<rollno<<endl;
				fs.close();
			}
		}
		void display_info()
		{
			ifstream fs;
			fs.open("sample.txt",ios::in);
			while(!fs.eof())
			{
				fs>>name;
				fs>>rollno;
				if(!fs.eof())
					cout<<name<<" "<<rollno<<endl;
			}
			fs.close();
		}
};

int main()
{
	int choice = 0;
	Student s;
	while(choice!=3)
	{
		cout<<"\n-------------------------"<<endl;
		cout<<"1 : Add information"<<endl;
		cout<<"2 : Display information"<<endl;
		cout<<"3 : Exit"<<endl;
		cout<<"Enter your choice: ";
		cin>>choice;
		switch(choice)
		{
			case 1:
				s.add_info();
				break;
			case 2:
				s.display_info();
				break;
			case 3:
				break;
			default:
				cout<<"Invalid choice..."<<endl;
				break;
		}
	}
	return 0;
}