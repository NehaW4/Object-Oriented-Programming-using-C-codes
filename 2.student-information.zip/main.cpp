/******************************************************************************
Develop a program in C++ to create a database of student’s information system containing the
following information: Name, Roll number, Class name -cn, Division-d, Date of Birth-dob, Blood group-blg, Contact
address, Telephone number, Driving license no-dlo. and other. Construct the database with
suitable member functions. Make use of constructor, default constructor, copy constructor,
destructor, static member functions, friend class, this pointer, inline code and dynamic
memory allocation operators-new and delete as well as exception handling.
*******************************************************************************/

#include <iostream>
using namespace std;
class person{
    
	private:
		string name,blg,dlo,dob;
		
	public:
		friend class student;
		
		person()
		{
			name="",
			blg="",
			dlo="",
			dob="";
		}
};

class student{
    
	private:
		string cn;
		char *div, d;
		int roll;
		
		
	public:
		student()
		{
			cn="",
			roll=0,
			div=NULL;
		}
		
		void acceptperson(person &p){
			cout<<"Enter name : "<<endl;
			cin>>p.name;
			cout<<"Enter blood group : "<<endl;
			cin>>p.blg;
			cout<<"Enter driving license number : "<<endl;
			cin>>p.dlo;
			cout<<"Enter dob : "<<endl;
			cin>>p.dob;
			cout<<"Enter roll no : "<<endl;
			cin>>roll;
			cout<<"Enter class name : "<<endl;
			cin>>cn;
			cout<<"Enter div : "<<endl;
			cin>>d;
			div = &d;
		}
		void displaystudent(person &p){
			cout<<"Name:            "<<p.name<<endl;
			cout<<"Blood Group:     "<<p.blg<<endl;
			cout<<"Driving License: "<<p.dlo<<endl;
			cout<<"DOB:             "<<p.dob<<endl;
			cout<<"Roll No.:        "<<roll<<endl;
			cout<<"Clsss Name:      "<<cn<<endl;
			cout<<"Div:             "<<div<<endl;
		}
		~student(){
			delete(div);
		}
};

int main()
{
	person p;
	student s;
	while(1){
		int ch;
		cout<<"Enter \n1.Enter a student \n2.Display \n3.Exit"<<endl;
		cin>>ch;
		if(ch==1){
			s.acceptperson(p);
		}
		else if(ch==2){
			s.displaystudent(p);
		}
		else{
			break;
		}
	}
	return 0;
}





