/****************************************************************************************
Implement a class Complex which represents the Complex Number data type. Implement the
following
1. Constructor (including a default constructor which creates the complex number 0+0i).
2. Overload operator+ to add two complex numbers.
3. Overload operator* to multiply two complex numbers.
4. Overload operators << and >> to print and read Complex Numbers.
****************************************************************************************/


#include<iostream>
using namespace std;

class Complex
{
  private:
  int real,img;
  
  public:
  Complex()
  {
    real=0;
    img=0;
  }
  
  Complex(int r, int i)
  {
    real=r;
    img=i;
  }
  
  void displayAdd()
  {
      cout<<"the addition is: "<<real<<"+"<<img<<"i"<<endl;
  }
  
  void displayMult()
  {
      cout<<"the multiplication is: "<<real<<"+"<<img<<"i"<<endl;
  }
  
  Complex operator+(Complex c)
  {
      Complex temp;
      temp.real = real + c.real;
      temp.img = img + c.img;
      return temp;
  }
  
  Complex operator*(Complex c)
  {
      Complex temp;
      temp.real = (real*c.real)-(img*c.img);
      temp.img = (real*c.img)+(img*c.real);
      return temp;
  }
};

int main()
{
    int a,b,c,d;
    cout<<"enter first no:"<<endl;
    cin>>a>>b;
    cout<<"enter second no. : "<<endl;
    cin>>c>>d;
    Complex c1(a,b);
    Complex c2(c,d);
    Complex c3;
    Complex c4;
    
    c3 = c1+c2;
    c4 = c1*c2;
    
    c3.displayAdd();
    c4.displayMult();
    return 0;
}














